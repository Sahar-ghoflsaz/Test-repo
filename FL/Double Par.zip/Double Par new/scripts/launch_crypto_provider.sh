cd ~/PyGrid/apps/node/
./run.sh --id crypto_provider --host localhost --port 7602 --start_local_db
