cd ~/PyGrid/apps/node/
./run.sh --id bob --host localhost --port 7601 --start_local_db
