cd ~/PyGrid/apps/node/
./run.sh --id alice --host localhost --port 7600 --start_local_db
